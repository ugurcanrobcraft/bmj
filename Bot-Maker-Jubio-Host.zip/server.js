import express from "express";
import { Client, GatewayIntentBits } from "@jubbio/core";
import crypto from "node:crypto";
import path from "node:path";
import { fileURLToPath } from "node:url";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const app = express();
app.use(express.json({ limit: "256kb" }));
app.use(express.static(__dirname));

const PORT = Number(process.env.PORT || 3000);
const MAX_HOST_MS = 90 * 60 * 1000;
const hosts = new Map();

function safeId(x) {
  return String(x || "").replace(/[^a-zA-Z0-9_-]/g, "").slice(0, 80);
}

function parseArgs(s) {
  return String(s).split(";").map(x => x.trim());
}

function replaceVars(text, message) {
  const author = message.author || {};
  const channel = message.channel || {};
  return String(text)
    .replaceAll("$username", author.username || author.name || "Kullanıcı")
    .replaceAll("$nickname", author.displayName || author.username || "Kullanıcı")
    .replaceAll("$channelID", channel.id || "")
    .replaceAll("$channelName", channel.name || "")
    .replaceAll("$noMentionMessage", String(message.content || "").replace(/<@!?\d+>|<@&\d+>|<#\d+>/g, "").trim());
}

function evalMath(name, args) {
  const nums = args.map(Number);
  if (nums.some(n => !Number.isFinite(n))) return null;
  if (name === "sum") return nums.reduce((a,b) => a+b, 0);
  if (name === "sub") return nums.length >= 2 ? nums[0] - nums[1] : null;
  if (name === "multi") return nums.length >= 2 ? nums[0] * nums[1] : null;
  if (name === "divide") return nums.length >= 2 && nums[1] !== 0 ? nums[0] / nums[1] : null;
  return null;
}

function parseBMJ(code, message) {
  let text = replaceVars(code, message);
  const embed = {};
  let usedEmbed = false;

  text = text.replace(/\$(sum|sub|multi|divide)\[([^\]]*)\]/gi, (_, name, raw) => {
    const value = evalMath(name.toLowerCase(), parseArgs(raw));
    return value === null ? "" : String(value);
  });

  text = text.replace(/\$description\[([^\]]*)\]/gi, (_, v) => {
    embed.description = replaceVars(v, message); usedEmbed = true; return "";
  });
  text = text.replace(/\$title\[([^\]]*)\]/gi, (_, v) => {
    embed.title = replaceVars(v, message); usedEmbed = true; return "";
  });
  text = text.replace(/\$footer\[([^\]]*)\]/gi, (_, v) => {
    embed.footer = { text: replaceVars(v, message) }; usedEmbed = true; return "";
  });
  text = text.replace(/\$author\[([^\]]*)\]/gi, (_, v) => {
    embed.author = { name: replaceVars(v, message) }; usedEmbed = true; return "";
  });
  text = text.replace(/\$image\[([^\]]*)\]/gi, (_, v) => {
    embed.image = { url: replaceVars(v, message) }; usedEmbed = true; return "";
  });

  text = text.trim();
  if (usedEmbed) {
    if (text) embed.description = (embed.description ? embed.description + "\n" : "") + text;
    return { embeds: [embed] };
  }
  return { content: text || " " };
}

function attachCommands(client, commands) {
  const list = Array.isArray(commands) ? commands : [];
  client.on("messageCreate", async (message) => {
    try {
      if (!message || message.author?.bot) return;
      const content = String(message.content || "");
      const cmd = list.find(x => {
        const trigger = String(x.trigger || "").trim();
        return trigger && content.toLowerCase().startsWith(trigger.toLowerCase());
      });
      if (!cmd) return;

      const result = parseBMJ(String(cmd.code || ""), message);
      await message.reply(result);
    } catch (err) {
      console.error("Komut hatası:", err);
      try { await message.reply("❌ Komut çalıştırılırken bir hata oluştu."); } catch {}
    }
  });
}

async function stopHost(botId) {
  const id = safeId(botId);
  const item = hosts.get(id);
  if (!item) return false;

  clearTimeout(item.timer);
  try {
    if (typeof item.client.destroy === "function") {
      await item.client.destroy();
    } else if (typeof item.client.logout === "function") {
      await item.client.logout();
    }
  } catch (e) {
    console.error("Bot kapatma hatası:", e);
  }
  hosts.delete(id);
  return true;
}

app.get("/api/health", (_, res) => {
  res.json({ ok: true, service: "Bot Maker Jubio Host", hosts: hosts.size });
});

app.get("/api/bots/status/:id", (req, res) => {
  const id = safeId(req.params.id);
  const item = hosts.get(id);
  if (!item) return res.json({ online: false, remaining: 0, ready: false });
  res.json({
    online: true,
    ready: item.ready,
    remaining: Math.max(0, item.expiresAt - Date.now())
  });
});

app.post("/api/bots/start", async (req, res) => {
  const botId = safeId(req.body.botId);
  const token = String(req.body.token || "").trim();
  const commands = Array.isArray(req.body.commands) ? req.body.commands.slice(0, 200) : [];

  if (!botId) return res.status(400).json({ error: "botId gerekli." });
  if (!token) return res.status(400).json({ error: "Bot tokeni gerekli." });

  await stopHost(botId);

  const client = new Client({
    intents: [
      GatewayIntentBits.Guilds,
      GatewayIntentBits.GuildMessages,
      GatewayIntentBits.MessageContent
    ]
  });

  const expiresAt = Date.now() + MAX_HOST_MS;
  const timer = setTimeout(() => stopHost(botId), MAX_HOST_MS);

  const item = { client, expiresAt, timer, ready: false };
  hosts.set(botId, item);

  client.on("ready", () => {
    item.ready = true;
    console.log(`Bot hazır: ${client.user?.username || botId}`);
  });

  client.on("error", err => console.error(`Jubbio bot hatası [${botId}]:`, err));

  attachCommands(client, commands);

  try {
    await Promise.resolve(client.login(token));
    res.json({ ok: true, botId, expiresAt });
  } catch (err) {
    await stopHost(botId);
    res.status(400).json({ error: err?.message || "Jubbio login başarısız." });
  }
});

app.post("/api/bots/stop", async (req, res) => {
  const ok = await stopHost(req.body.botId);
  res.json({ ok });
});

app.listen(PORT, () => {
  console.log(`Bot Maker Jubio host: http://localhost:${PORT}`);
  console.log("Node.js 18+ ve @jubbio/core gerekir.");
});
